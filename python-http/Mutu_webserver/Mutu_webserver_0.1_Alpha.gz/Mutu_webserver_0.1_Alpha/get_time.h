#ifndef GET_TIME_H
#define GET_TIME_H


#define TIME_BUFFER_SIZE	40	/* buffer size of time_buffer  */

char *get_time_str(char *time_buf);



#endif

